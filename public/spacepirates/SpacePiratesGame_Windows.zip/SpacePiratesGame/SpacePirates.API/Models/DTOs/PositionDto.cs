namespace SpacePirates.API.Models.DTOs
{
    public class PositionDto
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
} 