namespace SpacePirates.API.Models.DTOs
{
    public class FuelSystemDto
    {
        public int CurrentLevel { get; set; }
        public double CurrentFuel { get; set; }
    }
} 