namespace SpacePirates.API.Models.DTOs
{
    public class HullDto
    {
        public int CurrentLevel { get; set; }
        public int CurrentIntegrity { get; set; }
    }
} 