namespace SpacePirates.API.Models.DTOs
{
    public class EngineDto
    {
        public int CurrentLevel { get; set; }
    }
} 