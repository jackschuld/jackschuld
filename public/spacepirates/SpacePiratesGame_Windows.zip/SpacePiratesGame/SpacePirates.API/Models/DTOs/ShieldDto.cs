namespace SpacePirates.API.Models.DTOs
{
    public class ShieldDto
    {
        public int CurrentLevel { get; set; }
        public int CurrentIntegrity { get; set; }
        public bool IsActive { get; set; }
    }
} 