namespace SpacePirates.API.Models.DTOs
{
    public class WeaponSystemDto
    {
        public int CurrentLevel { get; set; }
    }
} 