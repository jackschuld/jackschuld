namespace SpacePirates.API.Models.DTOs
{
    public class CargoSystemDto
    {
        public int CurrentLevel { get; set; }
        public int CurrentLoad { get; set; }
        public int MaxCapacity { get; set; }
    }
} 