namespace SpacePirates.Console.UI.Styles
{
    public class SolarSystemColors : BaseStyle
    {
        // Add properties/methods for solar system color styling
    }
} 