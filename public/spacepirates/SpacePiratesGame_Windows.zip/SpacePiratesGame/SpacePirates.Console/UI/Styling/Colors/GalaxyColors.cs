namespace SpacePirates.Console.UI.Styles
{
    public class GalaxyColors : BaseStyle
    {
        // Add properties/methods for galaxy color styling
    }
} 