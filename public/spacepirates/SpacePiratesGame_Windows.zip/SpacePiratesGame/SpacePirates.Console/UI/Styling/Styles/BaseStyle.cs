namespace SpacePirates.Console.UI.Styles
{
    public abstract class BaseStyle
    {
        // Define interface for color/style lookups
    }
} 