namespace SpacePirates.Console.UI.Styles
{
    public class InstructionsPanelStyle : BaseStyle
    {
        // Add properties/methods for instructions panel styling
    }
} 