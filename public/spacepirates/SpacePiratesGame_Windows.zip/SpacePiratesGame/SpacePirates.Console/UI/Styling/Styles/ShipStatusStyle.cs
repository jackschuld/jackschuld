namespace SpacePirates.Console.UI.Styles
{
    public class ShipStatusStyle : BaseStyle
    {
        // Add properties/methods for ship status panel styling
    }
} 