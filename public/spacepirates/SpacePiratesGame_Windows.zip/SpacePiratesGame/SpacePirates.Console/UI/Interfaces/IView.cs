namespace SpacePirates.Console.UI.Views
{
    public interface IView
    {
        // ... existing code ...
    }
} 