namespace SpacePirates.Console.UI.Views.Map
{
    public interface ISelectableMapView
    {
        object? SelectedObject { get; }
    }
} 