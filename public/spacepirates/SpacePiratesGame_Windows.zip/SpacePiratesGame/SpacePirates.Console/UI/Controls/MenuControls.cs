using SpacePirates.Console.UI.Views;

namespace SpacePirates.Console.UI.Controls
{
    public class MenuControls : BaseControls
    {
        public override void HandleInput(ConsoleKeyInfo key, BaseView view)
        {
            // Handle menu navigation (hjkl, enter, etc.)
        }
    }
} 