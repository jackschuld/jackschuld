SpacePirates Game - README
=========================

How to Play SpacePirates
------------------------

1. Download and unzip the entire SpacePiratesGame folder.
2. Double-click launch.bat to start the game.
   - This will open two windows: one for the API, one for the game itself.
3. When finished, close both windows.

Requirements
------------
- Windows 10 or newer
- .NET 8.0 SDK or newer must be installed: https://dotnet.microsoft.com/download

Troubleshooting
---------------
- If you see errors about missing .NET, install the .NET SDK from the link above.
- If the game window closes immediately, try running launch.bat as Administrator.
- Make sure you unzipped the entire folder and did not move launch.bat out of the SpacePiratesGame folder.

Enjoy the adventure! 